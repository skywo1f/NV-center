# Quorum-NV

Quorum-NV measures optically detected magnetic resonance (ODMR) in nitrogen-vacancy diamond. A Raspberry Pi Pico controls an ADF4351 microwave synthesizer and reads a TSL2591 light sensor. The desktop app can sweep the microwave frequency and plot the change in fluorescence, or stream the light sensor readings while you align the optics.

## Repository contents

| File | Purpose |
| --- | --- |
| [`odmrGui.py`](odmrGui.py) | Desktop controls, live plots, and CSV logging |
| [`ODMR.c`](ODMR.c) | Pico firmware source for microwave control and light measurements |
| [PCB Gerber archive](Gerber_nvBoard_PCB_nvBoard_2026-05-27.zip) | Board fabrication files |
| [Antenna mount](quorumNV-antenna%20mount.stl), [laser mount](quorumNV-laser%20mount.stl), [optical mount](quorumNV-optical%20mount.stl) | Printable mounting parts |

## Setup

You need a Pico running the matching firmware, a USB data cable, an ADF4351 and microwave antenna, and a TSL2591. For ODMR, the optical setup needs a laser, an NV diamond, and filtering to reject the excitation light at the detector.

The desktop app requires Python 3 with Tkinter, plus PySerial, NumPy, and Matplotlib. From the repository folder on Windows, run:

```powershell
py -m pip install pyserial numpy matplotlib
py .\odmrGui.py
```

On macOS or Linux, use `python3` in place of `py`. If the Tkinter import fails, install Tk support for your Python distribution.

## Run an ODMR scan

1. Connect the Pico by USB. In **Serial**, click **Refresh**, select the Pico's port, and click **Connect**. Leave **Baud** at `115200`, **Assert DTR** checked, and **Assert RTS** unchecked. Close any serial terminal using the same port.
2. Set up the optics so the laser illuminates the diamond and the detector collects its fluorescence. Place the microwave antenna close to the diamond. For a first scan near 2.87 GHz, run without an applied magnet.
3. In **ODMR sweep**, enter the settings below. Scroll the left settings pane if the fields are clipped. Choose a new CSV path for each run because the app overwrites existing files at the selected path.
4. Click **Start ODMR** in the **Run** panel at the top left. The log shows the requested frequencies and measurements. The **ODMR plot** tab shows mean Δ versus frequency.

| Field | First-scan setting |
| --- | ---: |
| Start GHz | `2.840` |
| Stop GHz | `2.900` |
| Step GHz | `0.001` |
| Repeats/freq | `1` |
| Meas timeout s | `25` |
| CSV path | `first_sweep.csv` |

This sweep takes about seven minutes with the default timing settings. The app's initial sweep settings span 2.81 to 2.93 GHz in 100 kHz steps with four repeats, which takes about nine hours. If you find a candidate dip, narrow the range around it and take more repeats to check whether it persists.

## How to read the results

At each requested frequency, the Pico records three averages of the TSL2591 channel 0 counts in order, with microwaves off, on, and off again. The two off readings bracket the on reading to help account for slow baseline drift. The CSV contains one row per completed repeat.

| CSV column | Meaning |
| --- | --- |
| `freq_hz` | Requested microwave frequency in Hz |
| `repeat_idx` | Zero-based repeat index at that frequency |
| `off1`, `on`, `off2` | Mean detector counts in each microwave state |
| `off_ref` | Mean of `off1` and `off2` |
| `delta_on_minus_offref` | `on - off_ref`, in detector counts |
| `contrast_on_minus_offref_over_offref` | Signed fractional change. The firmware returns zero when `off_ref` is zero. |
| `drift_off2_minus_off1` | Change in the microwave-off baseline between the two readings |

An ODMR resonance can appear as a negative dip in Δ. Read the drift column alongside Δ to see whether the baseline is changing by a comparable amount. With multiple repeats, the plotted error bars show the standard error of mean Δ at each frequency. A single repeat gives no estimate of repeat-to-repeat uncertainty.

## Check the light sensor

Click **Start Light** and select **Light plot** to see live CH0 (visible plus infrared), CH1 (infrared), and estimated lux. Check that CH0 responds to changes in illumination and that the reading stays away from saturation during alignment. The lux estimate is a separate display value. ODMR uses CH0 counts.

To record the stream, enable **CSV log** in the light settings and choose an output path before starting. The CSV includes time since Pico boot in seconds, both channels, estimated lux when available, and the raw serial line. Click **Stop** before starting an ODMR sweep.

## Firmware and hardware interface

This repository ships `ODMR.c` as source. To flash a blank Pico, bring it into a Pico SDK project for your board, link `pico_stdlib`, `hardware_spi`, and `hardware_i2c`, enable USB stdio, and generate a UF2 with the SDK build. This archive does not include a build project or a compiled image.

The GPIO numbers below are Pico GPIO identifiers, independent of physical header pin numbers.

| Peripheral | Signal | Pico GPIO |
| --- | --- | --- |
| ADF4351 | SPI clock | GP18 |
| ADF4351 | SPI data from Pico | GP19 |
| ADF4351 | Latch enable | GP17 |
| ADF4351 | Chip enable | GP16 |
| TSL2591 | I²C SDA | GP0 |
| TSL2591 | I²C SCL | GP1 |

The firmware uses SPI0, assumes a **25 MHz** ADF4351 reference, and addresses the TSL2591 at **`0x29`** on I²C0. For a bench test from a serial terminal, close the GUI connection and send newline-terminated commands:

| Command | Expected response or effect |
| --- | --- |
| `GETCFG` | Returns `CFGSTATE,...` with the current timing settings |
| `MEAS 2870000000` | Measures one point at 2.87 GHz and returns `RESULT,...` |
| `MODE STREAM` | Starts continuous `DATA,...` light readings |
| `STREAM OFF` | Stops the light stream |

## Troubleshooting

| Symptom | What to check |
| --- | --- |
| Pico port is missing | Try a USB data cable, click **Refresh**, and check whether your computer detects the Pico as a serial device. |
| Port opens but the app times out | Look for `CFGSTATE` after **Send config only**. For a single-point test, set the start and stop to `2.870` with one repeat, then look for `RESULT` or a firmware error in the log. |
| `ERR,sensor_init_failed` at boot | Check sensor power, common ground, and SDA/SCL wiring. The firmware stops accepting commands if initialization fails. |
| Light readings are flat or near full scale | Check sensor alignment, stray light, and the optical filter. Try a shorter **IT ms** if the readings are near saturation. |
| Results arrive but no resonance dip is visible | Check that the detector sees fluorescence and that the synthesizer is producing the requested RF output at the antenna. A `RESULT` line confirms completion of the measurement sequence. |
| A scan takes longer than expected | Each repeat collects three sets of readings, including discarded samples. The default GUI timing takes about 6.7 seconds per repeat before serial and UI overhead. |

## License

[MIT](LICENSE)
